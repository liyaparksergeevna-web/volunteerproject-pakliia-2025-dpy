package com.example.volunteersystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VolunteerInfoSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
