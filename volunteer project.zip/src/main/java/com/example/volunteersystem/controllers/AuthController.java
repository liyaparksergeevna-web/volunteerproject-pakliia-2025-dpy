package com.example.volunteersystem.controllers;

import com.example.volunteersystem.models.User;
import com.example.volunteersystem.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // ----- страница регистрации -----
    @GetMapping("/registration")
    public String showRegistrationForm() {
        return "registration";
    }

    // ----- обработка регистрации -----
    @PostMapping("/registration")
    public String registerUser(@RequestParam String username,
                               @RequestParam String password,
                               Model model) {
        if (userRepository.findByUsername(username).isPresent()) {
            model.addAttribute("error", "Такой логин уже существует!");
            return "registration";
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(password));
        userRepository.save(user);

        model.addAttribute("message", "Регистрация успешна! Теперь войдите.");
        return "login";
    }

    // ----- страница входа -----
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    // ----- личный кабинет -----
    @GetMapping("/profile")
    public String userProfile(Model model,
                              org.springframework.security.core.Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        model.addAttribute("username", authentication.getName());
        return "profile";
    }

    // ----- выход -----
    @GetMapping("/logout")
    public String logoutPage() {
        return "redirect:/login";
    }
}
