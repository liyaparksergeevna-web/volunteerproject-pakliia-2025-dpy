package com.example.volunteersystem.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    // Главная страница (index.html)
    @GetMapping("/")
    public String home() {
        return "index";
    }

    // Можно добавить доп.проверку
    @GetMapping("/about")
    public String about() {
        return "about";
    }
}
