package com.example.volunteersystem.config;

public class AppException extends Exception {
}