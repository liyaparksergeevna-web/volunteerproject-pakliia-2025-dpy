package com.example.volunteersystem.models;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Table(name = "events")
@Data
public class Event {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;            // название мероприятия
    private String description;      // описание
    private String location;         // место проведения
    private LocalDateTime dateTime;  // дата и время

    private String coordinator;      // координатор мероприятия
    private Integer maxParticipants; // лимит участников
}
